import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.transforms.functional as TF
from einops import rearrange, repeat
from thop import profile
import time
from thop import profile


# ViT
# ==========================================
def pair(t):
    return t if isinstance(t, tuple) else (t, t)


class PatchEmbed(nn.Module):
    def __init__(self, img_size=224, patch_size=16, in_c=3, embed_dim=768, norm_layer=None):
        super().__init__()
        img_size = pair(img_size)
        patch_size = pair(patch_size)
        self.img_size = img_size
        self.patch_size = patch_size
        self.grid_size = (img_size[0] // patch_size[0],
                          img_size[1] // patch_size[1])
        self.num_patches = self.grid_size[0] * self.grid_size[1]

        self.proj = nn.Conv2d(
            in_c, embed_dim, kernel_size=patch_size, stride=patch_size)
        self.norm = norm_layer(embed_dim) if norm_layer else nn.Identity()

    def forward(self, x):
        B, C, H, W = x.shape
        assert H == self.img_size[0] and W == self.img_size[1], \
            f"Input image size ({H}*{W}) doesn't match model ({self.img_size[0]}*{self.img_size[1]})."

        x = self.proj(x).flatten(2).transpose(1, 2)
        x = self.norm(x)
        return x


class FeedForward(nn.Module):
    def __init__(self, dim, hidden_dim, dropout=0.):
        super().__init__()
        self.net = nn.Sequential(
            nn.LayerNorm(dim),
            nn.Linear(dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, dim),
            nn.Dropout(dropout)
        )

    def forward(self, x):
        return self.net(x)


class Attention(nn.Module):
    def __init__(self, dim, heads=8, dim_head=64, dropout=0.):
        super().__init__()
        inner_dim = dim_head * heads
        project_out = not (heads == 1 and dim_head == dim)

        self.heads = heads
        self.scale = dim_head ** -0.5

        self.norm = nn.LayerNorm(dim)
        self.attend = nn.Softmax(dim=-1)
        self.dropout = nn.Dropout(dropout)

        self.to_qkv = nn.Linear(dim, inner_dim * 3, bias=False)

        self.to_out = nn.Sequential(
            nn.Linear(inner_dim, dim),
            nn.Dropout(dropout)
        ) if project_out else nn.Identity()

    def forward(self, x, q_weight=None, k_weight=None, v_weight=None):
        x = self.norm(x)

        qkv = self.to_qkv(x).chunk(3, dim=-1)
        q, k, v = map(lambda t: rearrange(t, 'b n (h d) -> b h n d', h=self.heads), qkv)

        # 应用权重，假设权重形状为 [B, 1, 1, 1]
        if q_weight is not None:
            q = q * q_weight.unsqueeze(1)  # 扩展维度以匹配 [B, heads, seq, dim_head]
        if k_weight is not None:
            k = k * k_weight.unsqueeze(1)
        if v_weight is not None:
            v = v * v_weight.unsqueeze(1)

        dots = torch.matmul(q, k.transpose(-1, -2)) * self.scale
        attn = self.attend(dots)
        attn = self.dropout(attn)

        out = torch.matmul(attn, v)
        out = rearrange(out, 'b h n d -> b n (h d)')
        return self.to_out(out)


class Transformer(nn.Module):
    def __init__(self, dim, depth, heads, dim_head, mlp_dim, dropout=0.):
        super().__init__()
        self.layers = nn.ModuleList([])
        for _ in range(depth):
            self.layers.append(nn.ModuleList([
                Attention(dim, heads=heads,
                          dim_head=dim_head, dropout=dropout),
                FeedForward(dim, mlp_dim, dropout=dropout)
            ]))
        self.norm = nn.LayerNorm(dim)

    def forward(self, x):
        for attn, ff in self.layers:
            x = attn(x) + x
            x = ff(x) + x
        return self.norm(x)


class ViT(nn.Module):
    def __init__(self, *, image_size, patch_size, num_classes=None, dim, depth, heads, mlp_dim, pool='cls', channels=3,
                 dim_head=64, dropout=0., emb_dropout=0., new_shape=None):
        super().__init__()
        image_height, image_width = pair(image_size)
        patch_height, patch_width = pair(patch_size)

        assert image_height % patch_height == 0 and image_width % patch_width == 0, 'Image dimensions must be divisible by the patch size.'

        num_patches = (image_height // patch_height) * (image_width // patch_width)

        self.to_patch_embedding = PatchEmbed(img_size=pair(image_size), patch_size=pair(patch_size), in_c=channels,
                                             embed_dim=dim)

        self.pos_embedding = nn.Parameter(torch.randn(1, num_patches, dim))
        self.dropout = nn.Dropout(emb_dropout)

        self.transformer = Transformer(
            dim, depth, heads, dim_head, mlp_dim, dropout)

        self.to_latent = nn.Identity()

        if num_classes is not None:
            self.conv_head = nn.Conv2d(dim, num_classes, kernel_size=1)
        else:
            self.conv_head = nn.Identity()
        if new_shape is not None:
            self.upsample = nn.Upsample(size=(new_shape, new_shape), mode='bilinear', align_corners=False)
        else:
            self.upsample = nn.Identity()

    def forward(self, img):
        x = self.to_patch_embedding(img)

        b, n, _ = x.shape

        x += self.pos_embedding
        x = self.dropout(x)

        x = self.transformer(x)

        # Converting tokens back to spatial dimensions
        new_dim = int(n ** 0.5)
        x = rearrange(x, 'b (h w) c -> b c h w', h=new_dim, w=new_dim)

        # Upsample to original image size
        x = self.upsample(x)
        x = self.conv_head(x)

        return x


# ==========================================

class DoubleConv(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(DoubleConv, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, 3, 1, 1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, 3, 1, 1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        return self.conv(x)


class lConv(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(lConv, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, 3, 1, 1, bias=False),  # 3x3卷积，填充1
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, 3, 1, 1, bias=False),  # MODIFIED: 原为1x1，改为3x3保持尺寸一致
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Sigmoid()
        )

    def forward(self, x):
        return self.conv(x)

    # 分块


class SpatialSplit(nn.Module):
    def __init__(self, split_type="grid"):
        super().__init__()
        self.split_type = split_type

    def forward(self, x):
        B, C, H, W = x.shape
        splits = []

        if self.split_type == "grid":
            assert H % 2 == 0 and W % 2 == 0, f"Height and Width must be even, got {H}x{W}"
            h_split = H // 2
            w_split = W // 2
            splits = [
                x[:, :, :h_split, :w_split],
                x[:, :, :h_split, w_split:],
                x[:, :, h_split:, :w_split],
                x[:, :, h_split:, w_split:]
            ]
        elif self.split_type == "horizontal":
            assert W % 4 == 0, f"Width must be divisible by 4, got {W}"
            w_split = W // 4
            splits = [x[:, :, :, i * w_split:(i + 1) * w_split] for i in range(4)]
        elif self.split_type == "vertical":
            assert H % 4 == 0, f"Height must be divisible by 4, got {H}"
            h_split = H // 4
            splits = [x[:, :, i * h_split:(i + 1) * h_split, :] for i in range(4)]
        else:
            raise ValueError(f"Unsupported split_type: {self.split_type}")

        return splits


# 改=======================================================================================================
class DepthWiseConv(nn.Module):
    def __init__(self, in_channel, out_channel):
        super(DepthWiseConv, self).__init__()
        # 逐通道卷积
        self.depth_conv = nn.Conv2d(in_channels=in_channel,
                                    out_channels=in_channel,
                                    kernel_size=3,
                                    stride=1,
                                    padding=1,
                                    groups=in_channel)
        # groups是一个数，当groups=in_channel时,表示做逐通道卷积
        # 逐点卷积
        self.point_conv = nn.Conv2d(in_channels=in_channel,
                                    out_channels=out_channel,
                                    kernel_size=1,
                                    stride=1,
                                    padding=0,
                                    groups=1)
        self.covn_1 = lConv(in_channel, in_channel)

    def forward(self, input):
        out_1 = self.depth_conv(input)
        DW_weight = self.covn_1(input)
        out_3 = self.point_conv(out_1)

        out = (out_3 + (out_1 * DW_weight))

        return out
    # ===========================================================================================================================


# 同位提取转注意力
class DW_Attention(nn.Module):
    def __init__(self, in_channels):
        super().__init__()
        self.TW = DepthWiseConv(in_channels, in_channels)  # 输入输出通道一致
        self.AT = nn.ReLU()
        self.fc = nn.Linear(in_channels, 1)
        self.sigmoid = nn.Sigmoid()

    def forward(self, combined):
        # 调用 DepthWiseConv 模块计算注意力权重
        attention_weights = self.TW(combined)
        attention_weights = self.AT(attention_weights)

        # 全局平均池化
        avg_pool = torch.mean(attention_weights, dim=(2, 3))
        # 通过全连接层和 Sigmoid 激活函数
        fc_output = self.fc(avg_pool)
        single_weight = self.sigmoid(fc_output)

        return single_weight.squeeze()


class ParentModule(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.attention = Attention(dim=dim)

    def forward(self, x, q_weight, k_weight, v_weight):
        out = self.attention(x, q_weight, k_weight, v_weight)
        return out


class SpatialWeightModule(nn.Module):
    def __init__(self, temperature=1.0, eps=1e-8):
        super().__init__()
        self.temperature = temperature
        self.eps = eps

    def forward(self, A: torch.Tensor, B: torch.Tensor) -> torch.Tensor:
        # 1. Softmax 处理
        A_prob = F.softmax(A / self.temperature, dim=1)
        B_prob = F.softmax(B / self.temperature, dim=1)

        # 2. 计算每个位置的通道平方差和
        diff = A_prob - B_prob
        ssd = torch.sum(diff ** 2, dim=1)  # 形状 [N, H, W]

        # 3. 归一化（每个位置单独计算分母）
        l2_A = torch.norm(A_prob, p=2, dim=1)  # [N, H, W]
        l2_B = torch.norm(B_prob, p=2, dim=1)
        denominator = l2_A * l2_B + self.eps
        normalized_metric = ssd / denominator  # [N, H, W]

        # 4. 转换为空间权重（Softmax 展平后归一化）
        n, h, w = normalized_metric.shape
        spatial_weights = F.softmax(normalized_metric.view(n, -1) / self.temperature, dim=1)
        spatial_weights = spatial_weights.view(n, h, w)  # 形状 [N, H, W]
        return spatial_weights


# 模块1主体
class CustomModule(nn.Module):
    def __init__(self):
        super(CustomModule, self).__init__()
        self.split_module = SpatialSplit(split_type="grid")
        self.dilated_conv = nn.Conv2d(
            in_channels=128,  # 使用动态通道数
            out_channels=128,
            kernel_size=7,
            padding=9,
            dilation=3,
            stride=1
        )
        self.hybrid_attention = DW_Attention(in_channels=128)
        self.SW = SpatialWeightModule()

    def forward(self, samping_processing):
        z1, z2, z3, z4 = samping_processing
        # row1 = torch.cat([z1, z2], dim=3)
        # row2 = torch.cat([z3, z4], dim=3)
        # combined = torch.cat([row1, row2], dim=2)

        # combined = self.dilated_conv(combined)

        # fen = self.split_module(combined)
        # p1, p2, p3, p4 = fen

        sub_images_1 = self.split_module(z1)
        A1, A2, A3, A4 = sub_images_1
        sub_images_2 = self.split_module(z2)
        B1, B2, B3, B4 = sub_images_2
        sub_images_3 = self.split_module(z3)
        C1, C2, C3, C4 = sub_images_3
        sub_images_4 = self.split_module(z4)
        D1, D2, D3, D4 = sub_images_4

        TX1 = torch.cat([A1, B1], dim=3)
        TX2 = torch.cat([C1, D1], dim=3)
        W1 = torch.cat([TX1, TX2], dim=2)
        hybrid_weights_1 = self.hybrid_attention(W1)

        TX3 = torch.cat([A2, B2], dim=3)
        TX4 = torch.cat([C2, D2], dim=3)
        W2 = torch.cat([TX3, TX4], dim=2)
        hybrid_weights_2 = self.hybrid_attention(W2)

        TX5 = torch.cat([A3, B3], dim=3)
        TX6 = torch.cat([C3, D3], dim=3)
        W3 = torch.cat([TX5, TX6], dim=2)

        TX7 = torch.cat([A4, B4], dim=3)
        TX8 = torch.cat([C4, D4], dim=3)
        W4 = torch.cat([TX7, TX8], dim=2)

        weights_3 = self.SW(W3, W4)
        # 新增维度扩展（关键修改）
        hybrid_weights_1 = hybrid_weights_1.unsqueeze(1).unsqueeze(2).unsqueeze(3)  # [B, 1, 1, 1]
        # p1 = p1 + (p1 * hybrid_weights_1)  # 维度匹配，可逐元素相乘
        if len(hybrid_weights_1.shape) == 1:
            hybrid_weights_1 = hybrid_weights_1.unsqueeze(0).unsqueeze(1).unsqueeze(2)  # [B, 1, 1, 1]
        else:
            # 处理其他情况
            pass

        # hybrid_weights_2 = self.hybrid_attention(W2)
        hybrid_weights_2 = hybrid_weights_2.unsqueeze(1).unsqueeze(2).unsqueeze(3)

        return hybrid_weights_1, hybrid_weights_2, weights_3


class he(nn.Module):
    def __init__(self):
        super(he, self).__init__()
        # 添加 dilated_conv 层的定义
        self.dilated_conv = nn.Conv2d(
            in_channels=128,
            out_channels=128,
            kernel_size=7,
            padding=9,
            dilation=3,
            stride=1
        )

    def forward(self, samping_processing):
        z1, z2, z3, z4 = samping_processing
        row1 = torch.cat([z1, z2], dim=3)
        row2 = torch.cat([z3, z4], dim=3)
        combined = torch.cat([row1, row2], dim=2)

        combined = self.dilated_conv(combined)  # 现在可以正确访问

        return combined


class JointBilateralFilter_Upsampe_1(nn.Module):  # 添加继承nn.Module
    def __init__(self, sigma_spatial, sigma_color, kernel_size, in_channel, out_channel):
        super(JointBilateralFilter_Upsampe_1, self).__init__()
        """
        sigma_spatial: 空间域标准差，控制空间权重
        sigma_color: 颜色域标准差，控制颜色权重
        kernel_size: 滤波器核大小（奇数）
        """
        self.sigma_spatial = sigma_spatial
        self.sigma_color = sigma_color
        self.kernel_size = kernel_size
        self.pad = kernel_size // 2
        self.register_buffer('spatial_weights', self._create_spatial_weights())  # 注册为buffer
        self.upconv = nn.ConvTranspose2d(in_channel, out_channel, kernel_size=2, stride=2)

    def _create_spatial_weights(self):
        """生成空间高斯权重核"""
        grid = torch.arange(self.kernel_size, dtype=torch.float32) - self.kernel_size // 2
        x, y = torch.meshgrid(grid, grid, indexing='ij')
        kernel = torch.exp(-(x ** 2 + y ** 2) / (2 * self.sigma_spatial ** 2))
        return kernel.view(1, 1, self.kernel_size, self.kernel_size)  # (1,1,K,K)

    def forward(self, input_image, guide_image):
        """
        输入图像和引导图像进行联合双边滤波及上采样
        input_image: 待滤波图像 (B,C,H,W)
        guide_image: 引导图像 (B,C,H,W)
        返回: 滤波并上采样后的图像 (B,C,2*H, 2*W)
        """
        device = input_image.device
        self.spatial_weights = self.spatial_weights.to(device)

        # 图像填充
        input_pad = F.pad(input_image, [self.pad] * 4, mode='reflect')
        guide_pad = F.pad(guide_image, [self.pad] * 4, mode='reflect')

        # 提取滑动窗口块 (B,C,H_out,W_out,K,K)
        input_patches = input_pad.unfold(2, self.kernel_size, 1).unfold(3, self.kernel_size, 1)
        guide_patches = guide_pad.unfold(2, self.kernel_size, 1).unfold(3, self.kernel_size, 1)

        # 计算颜色差异 (中心点与邻域的差)
        c = self.kernel_size // 2  # 中心点索引
        guide_centers = guide_patches[..., c, c].unsqueeze(-1).unsqueeze(-1)  # (B,C,H_out,W_out,1,1)
        color_diff = guide_patches - guide_centers  # 广播减法 (B,C,H_out,W_out,K,K)

        # 计算颜色权重 (B,1,H_out,W_out,K,K)
        color_weights = torch.exp(-color_diff.pow(2).sum(dim=1, keepdim=True) / (2 * self.sigma_color ** 2))

        # 联合权重并归一化
        joint_weights = self.spatial_weights * color_weights  # 广播相乘 (B,1,H_out,W_out,K,K)
        norm = joint_weights.sum(dim=(-2, -1), keepdim=True) + 1e-8  # 归一化因子
        weights = joint_weights / norm

        # 应用权重并聚合结果
        output = (input_patches * weights).sum(dim=(-2, -1))  # (B,C,H_out,W_out)

        # output_upsampled = F.interpolate(output, scale_factor=2, mode='bilinear', align_corners=False)
        output = self.upconv(output)

        return output



class model2(nn.Module):
    def __init__(self, in_channels_x1, in_channels_x2, out_channels, t=0.6):
        super(model2, self).__init__()
        self.t = t
        reduced_channels = 128

        # 使用卷积调整 x2 的尺寸（仅调整通道）
        self.align_x2 = nn.Conv2d(in_channels_x2, in_channels_x1, kernel_size=3, padding=1, stride=1)

        # 通道降维
        self.reduce_x1 = nn.Conv2d(in_channels_x1, reduced_channels, kernel_size=1)
        self.reduce_x2 = nn.Conv2d(in_channels_x1, reduced_channels, kernel_size=1)

        # 多尺度卷积
        self.conv3x3 = nn.Conv2d(reduced_channels, reduced_channels, kernel_size=3, padding=1)
        self.conv5x5 = nn.Conv2d(reduced_channels, reduced_channels, kernel_size=5, padding=2)

        # 使用不同膨胀率的膨胀卷积
        self.dilated_conv1 = nn.Conv2d(reduced_channels, reduced_channels, kernel_size=3, padding=2, dilation=2)
        self.dilated_conv2 = nn.Conv2d(reduced_channels, reduced_channels, kernel_size=3, padding=3, dilation=3)
        self.dilated_conv3 = nn.Conv2d(reduced_channels, reduced_channels, kernel_size=3, padding=4, dilation=4)

        # 融合所有多尺度特征
        self.conv_fusion = nn.Conv2d(reduced_channels * 6, reduced_channels, kernel_size=1)

        # 多层 MLP 处理
        self.mlp = nn.Sequential(
            nn.Linear(reduced_channels, reduced_channels),
            nn.ReLU(),
            nn.Linear(reduced_channels, reduced_channels),
            nn.ReLU(),
            nn.Linear(reduced_channels, reduced_channels)
        )

        # 相似性计算后的通道变换
        self.pointwise_conv1 = nn.Conv2d(reduced_channels * 2, out_channels, kernel_size=1)

        # 新增：用于恢复通道数
        self.pointwise_conv2 = nn.Conv2d(out_channels + in_channels_x1, in_channels_x1, kernel_size=1)

    def forward(self, x1, x2):
        B, _, H1, W1 = x1.shape
        x2_aligned = self.align_x2(x2)

        # 通道降维
        x1_1 = self.reduce_x1(x1)
        x2 = self.reduce_x2(x2_aligned)

        # 调整 x2 尺寸
        x2 = F.interpolate(x2, size=x1.shape[2:], mode='bilinear', align_corners=False)

        # 多尺度特征提取
        def multi_scale_features(x):
            x_conv3 = self.conv3x3(x)
            x_conv5 = self.conv5x5(x)
            x_dilated1 = self.dilated_conv1(x)
            x_dilated2 = self.dilated_conv2(x)
            x_dilated3 = self.dilated_conv3(x)
            return self.conv_fusion(torch.cat([x, x_conv3, x_conv5, x_dilated1, x_dilated2, x_dilated3], dim=1))

        x1_fused = multi_scale_features(x1_1)
        x2_fused = multi_scale_features(x2)

        # 归一化
        h_norm = (x1_fused - x1_fused.mean(dim=(2, 3), keepdim=True)) / (x1_fused.std(dim=(2, 3), keepdim=True) + 1e-6)
        v_norm = (x2_fused - x2_fused.mean(dim=(2, 3), keepdim=True)) / (x2_fused.std(dim=(2, 3), keepdim=True) + 1e-6)

        c = torch.abs(h_norm - v_norm)
        one_minus_c = 1 - c
        max_hv = torch.max(h_norm, v_norm)
        min_hv = torch.min(h_norm, v_norm)
        mean_hv = (h_norm + v_norm) / 2

        mask_similar = (self.t <= one_minus_c) & (one_minus_c < 1)
        result_similar = max_hv - ((1 - c - self.t) / (1 - self.t)) * (max_hv - mean_hv)

        mask_boundary = (one_minus_c == self.t)
        result_boundary = mean_hv

        mask_different = (0 < one_minus_c) & (one_minus_c < self.t)
        result_different = min_hv + ((self.t - (1 - c)) / max(self.t, 1e-6)) * (mean_hv - min_hv)

        mask_total_diff = (one_minus_c == 0)
        result_total_diff = min_hv

        mask_similar = mask_similar.float()
        mask_boundary = mask_boundary.float()
        mask_different = mask_different.float()
        mask_total_diff = mask_total_diff.float()

        q = (mask_similar * result_similar +
             mask_boundary * result_boundary +
             mask_different * result_different +
             mask_total_diff * result_total_diff)

        # MLP 处理
        q = q.permute(0, 2, 3, 1)
        q = self.mlp(q)
        q = q.permute(0, 3, 1, 2)

        # 先拼接再用 1x1 卷积恢复通道
        combined = torch.cat((q, x1_fused), dim=1)
        output = self.pointwise_conv1(combined)
        output = torch.cat((output, x1), dim=1)  # 拼接原 x1
        output = self.pointwise_conv2(output)  # 1×1 卷积恢复通道

        return output


class WMNet_7_11(nn.Module):
    def __init__(self, in_channel, out_channel, t=0.6):  # 添加 t 参数
        super(WMNet_7_11, self).__init__()
        self.t = t  # 赋值给实例变量

        # Conv
        self.conv_1 = DoubleConv(in_channel, 32)
        self.conv_2 = DoubleConv(32, 64)
        self.conv_3 = DoubleConv(64, 128)
        self.conv_4 = DoubleConv(128, 256)
        self.conv_5 = DoubleConv(256, 512)

        self.conv_7 = DoubleConv(512, 256)
        self.conv_8 = DoubleConv(256, 128)
        self.conv_9 = DoubleConv(256, 64)

        self.conv1 = nn.Conv2d(128, 64, kernel_size=1)

        self.Dbconv_processing_1 = DoubleConv(64, 64)
        self.Dbconv_processing_2 = DoubleConv(256, 256)
        self.Dbconv_processing_3 = DoubleConv(128, 64)
        self.s_model = nn.Sequential(nn.Conv2d(256, 128, kernel_size=1),
                                     nn.Upsample(size=(224, 224), mode="bilinear", align_corners=False))

        self.final_conv = nn.Conv2d(32, out_channel, kernel_size=1)

        self.T_1 = nn.Conv2d(128, 64, kernel_size=1)  # 用于处理128通道的输入（如tx_2）
        self.T_2 = nn.Conv2d(512, 128, kernel_size=1)
        self.re = nn.Upsample(size=(64, 64), mode="bilinear", align_corners=False)

        self.tg = nn.Conv2d(64, 128, kernel_size=1)

        # Downsample
        self.downsample = nn.MaxPool2d(kernel_size=2, stride=2)
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2)

        # Upsample
        self.Upsample_d_1 = JointBilateralFilter_Upsampe_1(sigma_spatial=2.0, sigma_color=0.1, kernel_size=3,
                                                           in_channel=512, out_channel=256)
        self.Upsample_d_2 = JointBilateralFilter_Upsampe_1(sigma_spatial=2.0, sigma_color=0.1, kernel_size=3,
                                                           in_channel=256, out_channel=128)
        self.Upsample_d_3 = JointBilateralFilter_Upsampe_1(sigma_spatial=2.0, sigma_color=0.1, kernel_size=3,
                                                           in_channel=128, out_channel=64)
        self.Upsample_d_4 = JointBilateralFilter_Upsampe_1(sigma_spatial=2.0, sigma_color=0.1, kernel_size=3,
                                                           in_channel=64, out_channel=32)

        self.Upsample_s_1 = JointBilateralFilter_Upsampe_1(sigma_spatial=2.0, sigma_color=0.1, kernel_size=3,
                                                           in_channel=64, out_channel=128)
        self.Upsample_s_2 = JointBilateralFilter_Upsampe_1(sigma_spatial=2.0, sigma_color=0.1, kernel_size=3,
                                                           in_channel=128, out_channel=64)
        self.Upsample_s_3 = JointBilateralFilter_Upsampe_1(sigma_spatial=2.0, sigma_color=0.1, kernel_size=3,
                                                           in_channel=64, out_channel=128)
        self.Upsample_s_4 = JointBilateralFilter_Upsampe_1(sigma_spatial=2.0, sigma_color=0.1, kernel_size=3,
                                                           in_channel=128, out_channel=64)

        self.relu = nn.ReLU(inplace=True)

        self.mk_1 = he()
        self.mk_2 = CustomModule()

        self.DepthWiseConv_1 = DepthWiseConv(64, 64)
        self.DepthWiseConv_2 = DepthWiseConv(128, 128)
        self.DepthWiseConv_3 = DepthWiseConv(256, 256)
        self.DepthWiseConv_4 = DepthWiseConv(512, 512)
        self.model2 = model2(in_channels_x1=512, in_channels_x2=64, out_channels=512, t=self.t)
        self.output = nn.Conv2d(512, 64, kernel_size=1)  # 输出 (B, 64, 112, 112)

        self.parent_module = ParentModule(dim=64)

        self.vit_modle = ViT(
            image_size=112,  # 根据实际特征图尺寸调整
            patch_size=16,
            channels=128,
            dim=64,
            depth=3,
            heads=4,
            mlp_dim=256
        )

    def forward(self, x):
        # 深层，中层，浅层 = Deep, medium, shallow
        # tx 代表模块1对下采样的处理
        # x_d 代表深层支路， x_m 代表中层支路， x_s 代表浅层支路
        samping_processing = []
        # encoder
        x_ds_1 = self.conv_2(self.downsample(self.conv_1(x)))  # 64, 112, 112
        tx_1 = self.DepthWiseConv_1(x_ds_1)
        tx_1 = self.re(tx_1)
        tx_1 = self.tg(tx_1)
        tx_1 = F.interpolate(tx_1, size=(56, 56), mode='bilinear')
        samping_processing.append(tx_1)
        x_ds_1_1 = torch.cat((x_ds_1, x_ds_1), 1)  # 128, 112, 112

        x_d_2 = self.conv_3(self.downsample(x_ds_1))  # 128, 56, 56
        tx_2 = self.DepthWiseConv_2(x_d_2)
        # tx_2 = self.T_1(tx_2)
        tx_2 = F.interpolate(tx_2, size=(56, 56), mode='bilinear')
        samping_processing.append(tx_2)
        x_s_1_d = self.Upsample_s_1(x_ds_1, x_ds_1)  # 128, 112, 112
        x_s_1 = self.pool(x_s_1_d)
        x_s_1 = self.relu(x_s_1 + x_ds_1_1)
        x_s_1_1 = self.conv1(x_s_1)  # 64, 112, 112

        x_d_3 = self.conv_4(self.downsample(x_d_2))  # 256, 28, 28
        tx_3 = self.DepthWiseConv_3(x_d_3)
        tx_3 = self.s_model(tx_3)
        tx_3 = F.interpolate(tx_3, size=(56, 56), mode='bilinear')
        samping_processing.append(tx_3)
        x_s_2_d = self.Upsample_s_2(x_s_1, x_s_1)  # 64, 112, 112
        x_s_2 = self.pool(x_s_2_d)
        x_s_2 = self.relu(x_s_2 + x_s_1_1)
        x_s_2_1 = torch.cat((x_s_2, x_s_2), 1)  # 64, 112, 112

        x_d_4 = self.conv_5(self.downsample(x_d_3))  # 512, 14, 14
        tx_4 = self.DepthWiseConv_4(x_d_4)
        tx_4 = self.T_2(tx_4)
        tx_4 = F.interpolate(tx_4, size=(56, 56), mode='bilinear')
        samping_processing.append(tx_4)
        x_s_3_d = self.Upsample_s_3(x_s_2, x_s_2)  # 32, 112, 112
        x_s_3 = self.pool(x_s_3_d)
        x_s_3 = self.relu(x_s_3 + x_s_2_1)
        x_s_3_1 = self.conv1(x_s_3)  # 64, 112, 112
        x_d_5 = self.model2(x_d_4, x_s_3_1)
        x_d_5_new = F.interpolate(x_d_5, size=(112, 112), mode='bilinear', align_corners=False)
        x_d_5_new = self.output(x_d_5_new)

        # import pdb; pdb.set_trace()

        # decoder
        x_d_6 = self.Upsample_d_1(x_d_5, x_d_5)  # 512, 28, 28
        x_d_6 = self.conv_7(torch.cat((x_d_6, x_d_3), 1))  # 512, 28, 28

        x_d_7 = self.Upsample_d_2(x_d_6, x_d_6)  # 256, 56, 56
        x_d_7 = self.conv_8(torch.cat((x_d_7, x_d_2), 1))  # 256, 56, 56
        x_s_4_d = self.Upsample_s_4(x_s_3, x_s_3)  # 256, 224, 224
        x_s_4 = self.pool(x_s_4_d)  # 256, 112, 112
        x_s_4 = self.relu(x_s_4 + x_s_3_1)

        x_d_8 = self.Upsample_d_3(x_d_7, x_d_7)  # 128, 112, 112
        x_d_8 = self.conv_9(torch.cat((x_d_8, x_s_4, x_ds_1, x_d_5_new), 1))  # 64, 112, 112

        tx_z_1, tx_z_2, tx_z_5 = self.mk_2(samping_processing)  # mk_2是CustomModule，返回三个权重
        tx_z = self.mk_1(samping_processing)

        tx_z = self.vit_modle(tx_z)

        # 调整tx_z的空间尺寸（如果需要）
        if tx_z.shape[2:] != x_d_8.shape[2:]:
            tx_z = TF.resize(tx_z, size=x_d_8.shape[2:], interpolation=TF.InterpolationMode.NEAREST)
        # 拼接（64 + 64 = 128通道）
        x_d_8 = self.Dbconv_processing_3(torch.cat((x_d_8, tx_z), 1))

        x_d_9 = self.Upsample_d_4(x_d_8, x_d_8)  # 32, 224, 224

        return self.final_conv(x_d_9)


if __name__ == "__main__":

    # 初始化模型和输入
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")  # 自动检测设备
    x = torch.randn(4, 3, 224, 224).to(device)  # 假设输入为1张3通道224x224的图片
    model = WMNet_7_11(3, 9, 0.6).to(device)  # 确保模型也在设备上

    # 计算模型的FLOPs和参数量
    flops, params = profile(model, inputs=(x,))
    print(f'FLOPs: {flops}, params: {params}')

    # 测量推理时间
    model.eval()  # 切换到评估模式
    with torch.no_grad():  # 禁用梯度计算
        start_time = time.time()
        preds = model(x)
        if device.type == 'cuda':
            torch.cuda.synchronize()  # 如果使用GPU，需要同步
        end_time = time.time()

    # 计算推理时间
    inference_time = end_time - start_time
    print(f'Inference time: {inference_time:.6f} seconds')

    # 打印输入和输出的形状
    print(f'Input shape: {x.shape}')
    print(f'Output shape: {preds.shape}')