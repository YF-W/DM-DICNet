import torch
import torch.nn as nn

from thop import profile
import math

class DoubleConv(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(DoubleConv, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, 3, 1, 1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, 3, 1, 1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )
        self.convpoint = nn.Conv2d(in_channels, out_channels, kernel_size=1)

    def forward(self, x):
        y = self.conv(x)
        x = self.convpoint(x)
        x = y + x
        return x


class ViT(nn.Module):
    def __init__(self, in_channels, img_size, patch_size, embed_dim, num_heads, depth):
        super(ViT, self).__init__()
        self.patch_size = patch_size
        self.embed_dim = embed_dim
        self.patch_embedding = nn.Conv2d(in_channels, embed_dim, kernel_size=1, stride=1)
        num_patches = (img_size // patch_size) ** 2
        self.positional_encoding = nn.Parameter(torch.randn(1, num_patches, embed_dim))

        self.transformer_layers = nn.ModuleList(
            [nn.TransformerEncoderLayer(d_model=embed_dim, nhead=num_heads, batch_first=True) for _ in range(depth)]
        )

        self.proj = nn.Conv2d(embed_dim, in_channels, kernel_size=1)

    def forward(self, x):
        batch_size = x.shape[0]
        x = self.patch_embedding(x)
        x = x.flatten(2).transpose(1, 2)
        x = x + self.positional_encoding

        features = []  # 用于存储每层的输出
        for layer in self.transformer_layers:
            x = layer(x)
            features.append(x)  # 存储 Transformer 层的输出

        num_patches = x.size(1)
        patches_per_dim = int(num_patches ** 0.5)
        x = x.transpose(1, 2).view(batch_size, self.embed_dim, patches_per_dim, patches_per_dim)
        x = self.proj(x)

        fused_features = []
        for f in features:
            f = f.transpose(1, 2).view(batch_size, self.embed_dim, patches_per_dim, patches_per_dim)
            fused_features.append(self.proj(f))  # 投影到 CNN 维度

        return x, fused_features  # 返回最终输出和所有 Transformer 层的特征



class LocalGlobalFusion(nn.Module):
    def __init__(self, cnn_channels, vit_channels):
        super(LocalGlobalFusion, self).__init__()
        self.cnn_to_vit = nn.Conv2d(cnn_channels, vit_channels, kernel_size=1)
        self.vit_to_cnn = nn.Conv2d(vit_channels * 2, cnn_channels, kernel_size=1)
        self.attn = nn.Sequential(
            nn.Conv2d(cnn_channels//2, 1, kernel_size=1),
            nn.Sigmoid()
        )

    def forward(self, x_cnn, x_vit):
        cnn_guidance = self.cnn_to_vit(x_cnn)
        vit_guidance = self.vit_to_cnn(x_vit)

        attn_map = self.attn(cnn_guidance)
        enhanced_vit = x_vit * attn_map
        enhanced_cnn = x_cnn + vit_guidance

        return enhanced_cnn, enhanced_vit


class CorrelationBranch(nn.Module):
    def __init__(self, cnn_channels, vit_channels):
        super(CorrelationBranch, self).__init__()
        self.vit_projection = nn.Conv2d(512, cnn_channels, kernel_size=1)
        self.global_sim_conv = nn.Conv2d(cnn_channels, 1, kernel_size=1)

    def forward(self, x_cnn, x_vit):
        x_vit_resized = self.vit_projection(x_vit)

        if x_cnn.size(2) != x_vit_resized.size(2) or x_cnn.size(3) != x_vit_resized.size(3):
            x_vit_resized = F.interpolate(x_vit_resized, size=(x_cnn.size(2), x_cnn.size(3)), mode='bilinear',
                                          align_corners=False)

        cosine_sim_map = self.cosine_similarity(x_cnn, x_vit_resized)
        combined_sim_map = cosine_sim_map
        return combined_sim_map

    def cosine_similarity(self, x_cnn, x_vit):
        x_cnn_flat = x_cnn.view(x_cnn.size(0), x_cnn.size(1), -1)  # (B, C, N)
        x_vit_flat = x_vit.view(x_vit.size(0), x_vit.size(1), -1)  # (B, C, N)

        # 计算每个空间位置的L2范数，dim=1（通道维度）
        norm_cnn = torch.norm(x_cnn_flat, p=2, dim=1, keepdim=True)  # (B, 1, N)
        norm_vit = torch.norm(x_vit_flat, p=2, dim=1, keepdim=True)  # (B, 1, N)

        # 点积计算
        cosine_sim = torch.bmm(x_cnn_flat.transpose(1, 2), x_vit_flat)  # (B, N, N)
        # 归一化
        cosine_sim = cosine_sim / (norm_cnn.transpose(1, 2) @ norm_vit + 1e-8)  # (B, N, N)

        # 取对角线元素作为对应位置的相似度
        diagonal_sim = cosine_sim.diagonal(dim1=1, dim2=2)  # (B, N)
        cosine_sim_map = diagonal_sim.view(x_cnn.size(0), 1, x_cnn.size(2), x_cnn.size(3))  # (B, 1, H, W)

        return cosine_sim_map

import torch.nn.functional as F
import numpy as np
import math

# 工具函数 ----------------------------------------------------------------


def generate_matern_gp_noise_batch(B, H, W, length_scale=0.2, sigma=1.0, nu=1.5, device='cuda'):
    """生成基于 Matern 核的高斯过程噪声（批处理）"""
    freq_x = torch.fft.fftfreq(H, d=1.0).to(device)
    freq_y = torch.fft.fftfreq(W, d=1.0).to(device)
    fx, fy = torch.meshgrid(freq_x, freq_y, indexing='ij')
    f_norm = torch.sqrt(fx ** 2 + fy ** 2)

    d = 2
    alpha = 2 * nu + d
    C = (2 ** d * np.pi ** (d / 2) * torch.exp(
        torch.lgamma(torch.tensor(nu + d / 2)) - torch.lgamma(torch.tensor(nu)))) \
        / ((length_scale ** (2 * nu)) * (2 * nu) ** (d / 2))

    spectral_density = (sigma ** 2) * C / (
            (4 * np.pi ** 2 * f_norm ** 2 + (2 * nu) / length_scale ** 2) ** (alpha / 2)
    )
    spectral_density = spectral_density.clamp(min=1e-8)

    noise_batch = []
    for _ in range(B):
        white_noise = torch.randn(H, W, device=device) + 1j * torch.randn(H, W, device=device)
        filtered_freq = white_noise * torch.sqrt(spectral_density)
        noise = torch.fft.ifft2(filtered_freq).real
        noise = (noise - noise.mean()) / (noise.std() + 1e-6)
        noise_batch.append(noise.unsqueeze(0))

    return torch.stack(noise_batch, dim=0)  # shape: (B, 1, H, W)


def gaussian_kernel(size=5, sigma=1.0, device='cuda'):
    """生成高斯卷积核"""
    ax = torch.arange(size, dtype=torch.float32, device=device) - size // 2
    xx, yy = torch.meshgrid(ax, ax, indexing='ij')
    kernel = torch.exp(-(xx ** 2 + yy ** 2) / (2 * sigma ** 2))
    kernel = kernel / kernel.sum()
    return kernel.view(1, 1, size, size)


def apply_gaussian_filter(x, kernel_size=5, sigma=1.0):
    """对噪声应用高斯平滑"""
    B, C, H, W = x.shape
    kernel = gaussian_kernel(kernel_size, sigma, device=x.device)
    kernel = kernel.expand(C, 1, kernel_size, kernel_size)
    x = F.conv2d(x, kernel, padding=kernel_size // 2, groups=C)
    return x


# 主模型类 ---------------------------------------------------------------

class BATSMaternConvTranspose(nn.Module):
    """
    去注意力版本BATS Matern转置卷积层
    特点保留：
    - 融合Matern过程噪声和布朗对抗扰动
    - 动态卷积增强特征传播
    - 自适应强度调节
    """

    def __init__(
            self,
            in_channels,
            out_channels,
            kernel_size=4,
            stride=2,
            padding=1,
            output_padding=0,
            T=4,
            diffusion_sigma=2.0,
            matern_sigma=0.5,
            matern_length=0.2,
            matern_nu=1.5,
    ):
        super().__init__()

        # 基础转置卷积
        self.trans_conv = nn.ConvTranspose2d(
            in_channels, out_channels, kernel_size,
            stride, padding, output_padding
        )

        # 对抗扰动生成器（深度可分离结构）
        self.perturb_gen = nn.Sequential(
            nn.Conv2d(out_channels, out_channels // 2, 3, padding=1, groups=4),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(out_channels // 2, out_channels // 2, 3, padding=1, groups=4),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(out_channels // 2, out_channels, 3, padding=1),
        )

        # 布朗运动参数
        self.T = T
        self.log_diffusion_coeff = nn.Parameter(torch.log(torch.tensor(diffusion_sigma)))
        self._init_gaussian_kernel(diffusion_sigma)

        # Matern噪声参数
        self.matern_sigma = matern_sigma
        self.matern_length = matern_length
        self.matern_nu = matern_nu
        self.matern_scale = nn.Parameter(torch.tensor(1.0))

        # 自适应参数
        self.log_alpha = nn.Parameter(torch.log(torch.tensor(0.1)))

        # 动态卷积模块
        self.dynamic_conv = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(out_channels, 16, 1),
            nn.GELU(),
            nn.Conv2d(16, 9, 1)
        )

        # 参数初始化
        self._init_weights()

    def _init_gaussian_kernel(self, sigma):
        """初始化布朗运动扩散核"""
        kernel_size = 2 * int(3 * sigma) + 1
        ax = torch.arange(kernel_size) - kernel_size // 2
        xx, yy = torch.meshgrid(ax, ax, indexing="ij")
        kernel = torch.exp(-(xx ** 2 + yy ** 2) / (2 * sigma ** 2))
        kernel = kernel / kernel.sum()
        self.register_buffer("brownian_kernel", kernel.view(1, 1, kernel_size, kernel_size))

    def _init_weights(self):
        """参数初始化策略"""
        # 动态卷积层正交初始化
        nn.init.orthogonal_(self.dynamic_conv[1].weight)
        nn.init.orthogonal_(self.dynamic_conv[3].weight)

        # 扰动生成器初始化
        for m in self.perturb_gen.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='leaky_relu', a=0.2)

        # 其余卷积层默认初始化
        for m in self.modules():
            if isinstance(m, nn.Conv2d) and m not in self.perturb_gen:
                nn.init.normal_(m.weight, 0, 0.02)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)

    def _brownian_diffusion(self, delta):
        """布朗运动扩散过程"""
        B, C, H, W = delta.shape
        kernel = self.brownian_kernel.expand(C, 1, -1, -1).contiguous()

        # 分组卷积实现高效扩散
        delta = F.conv2d(
            delta,
            kernel.to(delta.device),
            padding=self.brownian_kernel.shape[-1] // 2,
            groups=C
        )

        # 添加随机噪声
        noise = torch.randn_like(delta) * torch.exp(self.log_diffusion_coeff) * math.sqrt(self.T)
        return delta + noise

    def _dynamic_convolution(self, x):
        """动态卷积实现"""
        B, C, H, W = x.shape

        # 生成通道自适应的卷积核参数
        kernel_params = self.dynamic_conv(x)  # [B, 9, 1, 1]
        kernel = kernel_params.view(B, 1, 3, 3)  # [B, 1, 3, 3]
        kernel = F.softmax(kernel, dim=1)  # 确保卷积核归一化

        # 重构输入张量维度
        x = x.view(1, B * C, H, W)  # [1, B*C, H, W]

        # 使用深度卷积实现通道独立处理
        return F.conv2d(
            x,
            kernel.repeat(C, 1, 1, 1),  # [B*C, 1, 3, 3]
            padding=1,
            groups=B * C  # 每个通道独立卷积
        ).view(B, C, H, W)

    def forward(self, x):
        # 基础特征上采样
        y_base = self.trans_conv(x)

        if self.training:
            # 生成初始扰动
            delta = self.perturb_gen(y_base)
            delta = F.dropout(delta, p=0.08, training=self.training)

            # 动态卷积增强
            delta = self._dynamic_convolution(delta)

            # Matern噪声融合
            B, C, H, W = delta.shape
            matern_noise = generate_matern_gp_noise_batch(
                B, H, W,
                length_scale=self.matern_length,
                sigma=self.matern_sigma,
                nu=self.matern_nu,
                device=x.device
            )
            matern_noise = apply_gaussian_filter(matern_noise)
            delta += self.matern_scale * matern_noise.expand_as(delta)

            # 布朗运动扩散
            delta = self._brownian_diffusion(delta)

            # 应用扰动
            alpha = torch.exp(self.log_alpha)
            y_out = y_base + alpha * torch.tanh(delta)
        else:
            y_out = y_base

        return y_out

    def get_config(self):
        """获取当前配置信息"""
        return {
            "diffusion_sigma": torch.exp(self.log_diffusion_coeff).item(),
            "alpha": torch.exp(self.log_alpha).item(),
            "matern_scale": self.matern_scale.item(),
        }

import torch
import torch.nn as nn
import torch.nn.functional as F



def _group_count(channels, max_groups=8):
    """Choose a GroupNorm group count that exactly divides channels."""
    for groups in range(min(max_groups, channels), 0, -1):
        if channels % groups == 0:
            return groups
    return 1


def _inverse_softplus(value):
    return math.log(math.expm1(value))


class VisualSaliency(nn.Module):
    """Estimate visual saliency from globally received self-attention mass.

    Attention is evaluated on a bounded spatial grid to avoid the quadratic
    memory cost of full-resolution attention. The column-wise (received)
    attention is used because the row-wise mean of a softmax matrix is constant.
    A lightweight local branch restores fine boundary detail after upsampling.
    """

    def __init__(self, channels, heads=4, attention_grid=7, reduction=6):
        super().__init__()
        if heads < 1:
            raise ValueError("heads must be positive")
        if attention_grid < 1:
            raise ValueError("attention_grid must be positive")
        if reduction < 1:
            raise ValueError("reduction must be positive")

        attention_dim = max(heads, channels // reduction)
        attention_dim = ((attention_dim + heads - 1) // heads) * heads
        self.heads = heads
        self.head_dim = attention_dim // heads
        self.attention_grid = attention_grid

        self.qk = nn.Conv2d(channels, 2 * attention_dim, kernel_size=1, bias=False)
        self.local_calibration = nn.Sequential(
            nn.Conv2d(channels, channels, kernel_size=3, padding=1,
                      groups=channels, bias=False),
            nn.Conv2d(channels, 1, kernel_size=1),
        )
        self.log_temperature = nn.Parameter(
            torch.tensor(_inverse_softplus(0.5), dtype=torch.float32)
        )
        self.log_local_gain = nn.Parameter(
            torch.tensor(_inverse_softplus(0.25), dtype=torch.float32)
        )

    def forward(self, x):
        batch, _, height, width = x.shape
        pooled_height = min(height, self.attention_grid)
        pooled_width = min(width, self.attention_grid)
        pooled = F.adaptive_avg_pool2d(x, (pooled_height, pooled_width))

        query, key = self.qk(pooled).chunk(2, dim=1)
        token_count = pooled_height * pooled_width
        query = query.reshape(batch, self.heads, self.head_dim, token_count).transpose(-2, -1)
        key = key.reshape(batch, self.heads, self.head_dim, token_count).transpose(-2, -1)

        logits = torch.matmul(query, key.transpose(-2, -1)) * (self.head_dim ** -0.5)
        attention = torch.softmax(logits.float(), dim=-1).to(dtype=logits.dtype)

        # Mean over queries gives the attention received by each token.
        received = attention.mean(dim=-2).mean(dim=1)
        relative_mass = (received * token_count).clamp_min(1e-6)
        global_score = torch.log(relative_mass).reshape(
            batch, 1, pooled_height, pooled_width
        )
        global_score = F.interpolate(
            global_score, size=(height, width), mode="bilinear", align_corners=False
        )

        local_score = torch.tanh(self.local_calibration(x))
        temperature = F.softplus(self.log_temperature) + 1e-4
        local_gain = F.softplus(self.log_local_gain)
        return torch.sigmoid((global_score + local_gain * local_score) / temperature)


class HashSemantic(nn.Module):
    """Build continuous local hash statistics and semantic reliability."""

    def __init__(self, channels, hash_dim=8, neighborhood_size=5):
        super().__init__()
        if hash_dim < 1:
            raise ValueError("hash_dim must be positive")
        if neighborhood_size < 1 or neighborhood_size % 2 == 0:
            raise ValueError("neighborhood_size must be a positive odd number")

        self.hash_dim = hash_dim
        self.neighborhood_size = neighborhood_size
        self.hash_layer = nn.Conv2d(channels, hash_dim, kernel_size=1)
        self.log_hash_temperature = nn.Parameter(
            torch.tensor(_inverse_softplus(1.0), dtype=torch.float32)
        )

    def forward(self, x):
        temperature = F.softplus(self.log_hash_temperature) + 1e-4
        soft_code = torch.tanh(self.hash_layer(x) / temperature)
        bit_probability = F.avg_pool2d(
            (soft_code + 1.0) * 0.5,
            kernel_size=self.neighborhood_size,
            stride=1,
            padding=self.neighborhood_size // 2,
            count_include_pad=False,
        )
        probability = bit_probability.float().clamp(1e-6, 1.0 - 1e-6)
        bit_entropy = -(
            probability * torch.log(probability)
            + (1.0 - probability) * torch.log(1.0 - probability)
        ) / math.log(2.0)
        reliability = (1.0 - bit_entropy.mean(dim=1, keepdim=True)).clamp(0.0, 1.0)
        return reliability.to(dtype=x.dtype)


class SemanticRegion(nn.Module):
    """Differentiable visual-semantic partition with learnable thresholds."""

    def __init__(self, visual_threshold=0.5, semantic_threshold=0.6,
                 temperature=0.1):
        super().__init__()
        if not 0.0 < visual_threshold < 1.0:
            raise ValueError("visual_threshold must lie in (0, 1)")
        if not 0.0 < semantic_threshold < 1.0:
            raise ValueError("semantic_threshold must lie in (0, 1)")
        if temperature <= 0.0:
            raise ValueError("temperature must be positive")
        self.visual_threshold_logit = nn.Parameter(
            torch.logit(torch.tensor(visual_threshold, dtype=torch.float32))
        )
        self.semantic_threshold_logit = nn.Parameter(
            torch.logit(torch.tensor(semantic_threshold, dtype=torch.float32))
        )
        self.log_temperature = nn.Parameter(
            torch.tensor(_inverse_softplus(temperature), dtype=torch.float32)
        )

    def forward(self, visual, semantic):
        visual_threshold = torch.sigmoid(self.visual_threshold_logit)
        semantic_threshold = torch.sigmoid(self.semantic_threshold_logit)
        temperature = F.softplus(self.log_temperature) + 1e-4

        visual_high = torch.sigmoid((visual - visual_threshold) / temperature)
        semantic_high = torch.sigmoid((semantic - semantic_threshold) / temperature)

        center = visual_high * semantic_high
        texture = (1.0 - visual_high) * semantic_high
        boundary = visual_high * (1.0 - semantic_high)
        background = (1.0 - visual_high) * (1.0 - semantic_high)

        partition = torch.cat((center, texture, boundary, background), dim=1)
        partition = partition / partition.sum(dim=1, keepdim=True).clamp_min(1e-6)
        return partition.chunk(4, dim=1)


class HashDiffusion(nn.Module):
    """Spatially varying Gaussian diffusion using a compact radius basis.

    Each token selects a continuous radius from visual and semantic evidence.
    Source-weighted Gaussian convolutions approximate token-wise Gaussian
    splatting, so overlapping token fields accumulate without constructing an
    impractical dense H*W by H*W diffusion matrix.
    """

    def __init__(self, channels, radii=(0.75, 1.5, 3.0), reduction=6,
                 layer_scale_init=1e-3):
        super().__init__()
        if reduction < 1:
            raise ValueError("reduction must be positive")
        if not radii or any(radius <= 0 for radius in radii):
            raise ValueError("radii must contain positive values")
        if tuple(sorted(radii)) != tuple(radii):
            raise ValueError("radii must be sorted in ascending order")

        hidden_channels = min(channels, max(8, channels // reduction))
        self.message_projection = nn.Conv2d(
            channels, hidden_channels, kernel_size=1, bias=False
        )
        self.message_norm = nn.GroupNorm(
            _group_count(hidden_channels), hidden_channels
        )
        self.output_projection = nn.Conv2d(
            hidden_channels, channels, kernel_size=1, bias=False
        )
        self.layer_scale = nn.Parameter(
            torch.full((1, channels, 1, 1), layer_scale_init)
        )

        self.register_buffer("radii", torch.tensor(radii, dtype=torch.float32))
        for index, sigma in enumerate(radii):
            half_width = max(1, int(math.ceil(2.0 * sigma)))
            coordinates = torch.arange(-half_width, half_width + 1, dtype=torch.float32)
            kernel = torch.exp(-0.5 * (coordinates / sigma).square())
            kernel = kernel / kernel.sum()
            self.register_buffer(f"gaussian_kernel_{index}", kernel, persistent=False)

        radius_step = min(
            (radii[index + 1] - radii[index] for index in range(len(radii) - 1)),
            default=radii[0],
        )
        self.log_basis_bandwidth = nn.Parameter(
            torch.tensor(_inverse_softplus(max(radius_step, 0.25)), dtype=torch.float32)
        )
        self.log_visual_radius_weight = nn.Parameter(
            torch.tensor(_inverse_softplus(2.0), dtype=torch.float32)
        )
        self.log_semantic_radius_weight = nn.Parameter(
            torch.tensor(_inverse_softplus(2.0), dtype=torch.float32)
        )
        self.radius_bias = nn.Parameter(torch.tensor(-2.0, dtype=torch.float32))

        # Monotonic priors enforce center > texture > boundary > background.
        self.texture_gate_logit = nn.Parameter(torch.logit(torch.tensor(0.65)))
        self.boundary_ratio_logit = nn.Parameter(torch.logit(torch.tensor(0.35)))

    @staticmethod
    def _separable_gaussian_blur(x, kernel):
        channels = x.shape[1]
        kernel = kernel.to(dtype=x.dtype)
        horizontal = kernel.view(1, 1, 1, -1).expand(channels, 1, 1, -1)
        vertical = kernel.view(1, 1, -1, 1).expand(channels, 1, -1, 1)
        padding = kernel.numel() // 2
        x = F.conv2d(x, horizontal, padding=(0, padding), groups=channels)
        return F.conv2d(x, vertical, padding=(padding, 0), groups=channels)

    def forward(self, residual, features, visual, semantic,
                center, texture, boundary, background):
        message = F.silu(self.message_norm(self.message_projection(features)))

        texture_gate = torch.sigmoid(self.texture_gate_logit)
        boundary_gate = texture_gate * torch.sigmoid(self.boundary_ratio_logit)
        propagation_gate = (
            center + texture_gate * texture + boundary_gate * boundary
        ) * (1.0 - background)

        visual_weight = F.softplus(self.log_visual_radius_weight)
        semantic_weight = F.softplus(self.log_semantic_radius_weight)
        normalized_radius = torch.sigmoid(
            visual_weight * visual + semantic_weight * semantic + self.radius_bias
        )
        min_radius = self.radii[0].to(dtype=features.dtype)
        max_radius = self.radii[-1].to(dtype=features.dtype)
        base_radius = min_radius + (max_radius - min_radius) * normalized_radius
        radius = min_radius + (base_radius - min_radius) * propagation_gate

        radii = self.radii.to(dtype=features.dtype).view(1, -1, 1, 1)
        bandwidth = F.softplus(self.log_basis_bandwidth).to(dtype=features.dtype) + 1e-4
        basis_logits = -0.5 * ((radius - radii) / bandwidth).square()
        basis_weights = torch.softmax(basis_logits, dim=1) * propagation_gate

        accumulated = torch.zeros_like(message)
        for index in range(self.radii.numel()):
            source = message * basis_weights[:, index:index + 1]
            kernel = getattr(self, f"gaussian_kernel_{index}")
            accumulated = accumulated + self._separable_gaussian_blur(source, kernel)

        # Destination gating keeps background closed and limits boundary leakage.
        accumulated = accumulated * propagation_gate
        delta = self.output_projection(accumulated)
        return residual + self.layer_scale * delta


class HVSBlock(nn.Module):
    """Hash-guided visual-semantic adaptive diffusion block."""

    def __init__(self, channels, hash_dim=8, attention_heads=4,
                 attention_grid=14, neighborhood_size=5,
                 diffusion_radii=(0.75, 1.5, 3.0)):
        super().__init__()
        self.norm = nn.GroupNorm(_group_count(channels), channels)
        self.visual = VisualSaliency(
            channels, heads=attention_heads, attention_grid=attention_grid
        )
        self.semantic = HashSemantic(
            channels, hash_dim=hash_dim, neighborhood_size=neighborhood_size
        )
        self.region = SemanticRegion()
        self.diffusion = HashDiffusion(channels, radii=diffusion_radii)

    def forward(self, x):
        features = self.norm(x)
        visual = self.visual(features)
        semantic = self.semantic(features)
        center, texture, boundary, background = self.region(visual, semantic)
        return self.diffusion(
            x, features, visual, semantic,
            center, texture, boundary, background,
        )
    
class ONet(nn.Module):
    def __init__(self, in_channels, out_channels, features=[64, 128, 256, 512],
                 vit_img_size=224, vit_patch_size=16, vit_embed_dim=256, vit_heads=4, vit_depth=4):
        super(ONet, self).__init__()
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2)
        self.vit_proj_1 = nn.Conv2d(vit_embed_dim * 2, features[2], kernel_size=1)
        self.vit_proj_2 = nn.Conv2d(vit_embed_dim * 2, features[1], kernel_size=1)
        self.vit_proj_3 = nn.Conv2d(vit_embed_dim * 2, features[0], kernel_size=1)
        self.vit_proj_4 = nn.Conv2d(vit_embed_dim * 2, features[0]//2, kernel_size=1)

        self.down1 = DoubleConv(in_channels, features[0])
        self.hvs1 = HVSBlock(features[0])
        self.down2 = DoubleConv(features[0], features[1])
        self.hvs2 = HVSBlock(features[1])
        self.down3 = DoubleConv(features[1], features[2])
        self.hvs3 = HVSBlock(features[2])
        self.down4 = DoubleConv(features[2], features[3])
        self.hvs4 = HVSBlock(features[3])

        self.vit = ViT(features[3], vit_img_size, vit_patch_size, vit_embed_dim, vit_heads, vit_depth)


        self.lg_fusion = LocalGlobalFusion(features[3], vit_embed_dim)
        self.corr_branch = CorrelationBranch(cnn_channels=features[3], vit_channels=vit_embed_dim)
        # self.FusionAttention = UnifiedAttentionFusion(in_channels=3)

        self.up1 = BATSMaternConvTranspose(features[3], features[2])
        self.conv_up1 = DoubleConv(features[3] * 2, features[2])
        self.up2 = BATSMaternConvTranspose(features[2], features[1])
        self.conv_up2 = DoubleConv(features[3], features[1])
        self.up3 = BATSMaternConvTranspose(features[1], features[0])
        self.conv_up3 = DoubleConv(features[2], features[0])
        self.up4 = BATSMaternConvTranspose(features[0], features[0],T=2)
        self.conv_up4 = DoubleConv(160, features[0])

        self.final_conv = nn.Conv2d(features[0], out_channels, kernel_size=1)

    def forward(self, x):
        # x = self.FusionAttention(x)
        down1 = self.down1(x)
        down1 = self.hvs1(down1)
        x = self.pool(down1)
        down2 = self.down2(x)
        down2 = self.hvs2(down2)
        x_2 = self.pool(down2)
        down3 = self.down3(x_2)
        down3 = self.hvs3(down3)
        x_3 = self.pool(down3)
        down4 = self.down4(x_3)
        down4 = self.hvs4(down4)
        x_cnn = self.pool(down4)

        x_vit, vit_features = self.vit(x_cnn)

        corr_attn = self.corr_branch(x_cnn, x_vit)
        x_cnn, x_vit = self.lg_fusion(x_cnn, x_vit)
        x_fused = x_cnn * (1 + corr_attn)

        # 上采样 ViT 特征，以匹配 CNN 层的尺寸
        vit_features_resized = [
            F.interpolate(f, size=(down4.size(2), down4.size(3)), mode='bilinear', align_corners=False) for f in
            vit_features
        ]
        x_vit_resized_1 = self.vit_proj_1(vit_features_resized[-1])
        x_vit_resized_2 = self.vit_proj_2(vit_features_resized[-2])
        x_vit_resized_3 = self.vit_proj_3(vit_features_resized[-3])
        x_vit_resized_4 = self.vit_proj_4(vit_features_resized[-4])


        # 使用上采样后的 ViT 特征进行跳连，调整尺寸匹配
        x = self.up1(x_fused)
        x = torch.cat([x, down4, x_vit_resized_1], dim=1)  # 跳连最后一层 ViT 特征
        x = self.conv_up1(x)

        x = self.up2(x)
        x = torch.cat([x, down3,
                       F.interpolate(x_vit_resized_2, size=(down3.size(2), down3.size(3)), mode='bilinear',
                                     align_corners=False)], dim=1)  # 调整 viT 特征尺寸
        x = self.conv_up2(x)

        x = self.up3(x)
        x = torch.cat([x, down2,
                       F.interpolate(x_vit_resized_3, size=(down2.size(2), down2.size(3)), mode='bilinear',
                                     align_corners=False)], dim=1)  # 调整 viT 特征尺寸
        x = self.conv_up3(x)

        x = self.up4(x)
        x = torch.cat([x, down1,
                       F.interpolate(x_vit_resized_4, size=(down1.size(2), down1.size(3)), mode='bilinear',
                                     align_corners=False)], dim=1)  # 调整 viT 特征尺寸
        x = self.conv_up4(x)

        prediction = self.final_conv(x)
        return prediction


def test():
    x = torch.randn(4, 3, 224, 224)
    model = ONet(in_channels=3, out_channels=1)
    preds = model(x)
    flops, params = profile(model, inputs=(x,))
    print(f'Flops: {flops}, params: {params}')
    print(preds.shape)


if __name__ == "__main__":
    test()
